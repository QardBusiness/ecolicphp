<?php

namespace app\controllers;

use app\base\Model;
use app\models\Arquivo;
use app\models\Faq;
use app\models\Requisicao;
use app\models\RequisicaoSearch;
use app\models\Texto;
use Goodby\CSV\Export\Standard\Exporter;
use Goodby\CSV\Export\Standard\ExporterConfig;
use Yii;
use yii\base\ErrorException;
use yii\db\Query;
use yii\filters\AccessControl;
use yii\helpers\ArrayHelper;
use yii\helpers\Inflector;
use yii\web\Controller;
use yii\web\JsExpression;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use yii\web\ServerErrorHttpException;
use yii\web\UploadedFile;
use yii\helpers\VarDumper;
use app\base\MiscHelper;
use yii2tech\spreadsheet\Spreadsheet;

class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        /*$model = Texto::findOne(['key' => 'apresentacao']);
        return $this->render('texto-db', ['model' => $model, 'titulo' => 'Apresentação']);*/
        return $this->redirect('site/requisicao');
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Creates a new Requisicao model
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionRequisicao()
    {
        $model = new Requisicao();
        $modelsArquivo = [new Arquivo];

        if ($model->load(Yii::$app->request->post())) {
            $modelsArquivo = Model::createMultiple(Arquivo::classname());
            Model::loadMultiple($modelsArquivo, Yii::$app->request->post());

            // validate all models
            $valid = $model->validate();
            //$valid = Model::validateMultiple($modelsArquivo) && $valid;

            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();

                try {
                    if ($flag = $model->save(false)) {
                        // Salva o protocolo
                        $model->protocolo = MiscHelper::geraProtocolo($model->id);
                        $model->save();

                        foreach ($modelsArquivo as $i => $modelArquivo) {
                            $modelArquivo->requisicao_id = $model->id;
                            $modelArquivo->file = \yii\web\UploadedFile::getInstance($modelArquivo, "[{$i}]file");

                            if (isset($modelArquivo->file)) {
                                $hash = Yii::$app->security->generateRandomString(8);
                                $tipoDoc = Inflector::slug($modelArquivo->tipoDocumento->nome);
                                $nomeArquivo = "{$tipoDoc}_{$model->id}_{$hash}.{$modelArquivo->file->extension}";
                                $basepath = 'upload/'.date('mY');
                                if (!file_exists($basepath)) {
                                    mkdir($basepath, 0775, true);
                                }

                                $path = $basepath.'/'.$nomeArquivo;

                                $modelArquivo->file->saveAs($path);
                                $modelArquivo->nome = $nomeArquivo;
                                $modelArquivo->path = $path;
                                $modelArquivo->tamanho = $modelArquivo->file->size;
                                $modelArquivo->extensao = $modelArquivo->file->extension;
                            }

                            if (! ($flag = $modelArquivo->save(false))) {
                                $transaction->rollBack();
                                @unlink($modelArquivo->path);
                                break;
                            }
                        }
                    }

                    if ($flag) {
                        $transaction->commit();
                        $model->enviaEmail();
                        Yii::$app->session->setFlash('success', $model->protocolo);
                        return $this->redirect('requisicao');
                    }
                } catch (\Exception $e) {
                    $transaction->rollBack();
                    Yii::error('Erro! | [site/requisicao] | '.$e->getMessage());
                    throw new ServerErrorHttpException('Houve uma falha no servidor ao processar os dados. Tente novamente mais tarde.');
                }
            }
        }

        return $this->render('_form_requisicao', [
            'model' => $model,
            'modelsArquivo' => (empty($modelsArquivo)) ? [new Arquivo] : $modelsArquivo
        ]);

    }

    /*public function actionLegislacao()
    {
        $model = Texto::findOne(['key' => 'legislacao']);
        return $this->render('texto-db', ['model' => $model, 'titulo' => 'Manuais']);
    }*/

    public function actionPerguntasRespostas()
    {
        $models = Faq::find()->all();
        return $this->render('perguntas-respostas', ['models' => $models]);
    }

    public function actionContato()
    {
        $model = Texto::findOne(['key' => 'contato']);
        return $this->render('texto-db', ['model' => $model, 'titulo' => 'Contato']);
    }

    public function actionSimulador()
    {
        $model = Texto::findOne(['key' => 'simulador']);
        return $this->render('texto-db', ['model' => $model, 'titulo' => 'Simulador']);
    }

    public function actionTeste($array = false)
    {
        ini_set('memory_limit','512M');
        $searchModel = new RequisicaoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, true);
        echo "<pre>";
        var_dump($dataProvider->getModels());
        //$dados = Requisicao::find()->joinWith(['regional', 'atividade'])->asArray()->limit(10)->all();
        //var_dump($dados);
    }

    public function actionTesteQuery()
    {
        ini_set('memory_limit','512M');

        $query = (new Query())
            ->select([
                'requisicao.id',
                'requisicao.protocolo',
                'requisicao.empreendedor',
                'requisicao.cpf_cnpj_empreendedor',
                'requisicao.empreendimento',
                'requisicao.cnpj_empreendimento',
                'municipio.nome as municipio',
                'requisicao.requerente',
                'requisicao.cpf_requerente',
                'requisicao.email',
                'requisicao.telefone',
                'regional.sigla as supram',
                'requisicao.tipo',
                'requisicao.retifica_protocolo',
                'requisicao.modalidade',
                'requisicao.classe',
                'requisicao.fator_locacional',
                'atividade.nome as atividade',
                'requisicao.status',
                'requisicao.processo_suppri',
                'requisicao.data',
                'requisicao.conclusao'
            ])
            ->from('requisicao')
            ->leftJoin('municipio', 'requisicao.municipio_id = municipio.id')
            ->leftJoin('regional', 'municipio.regional_id = regional.id')
            ->leftJoin('atividade', 'requisicao.atividade_id = atividade.id')
            ->all();

        $config = new ExporterConfig();
        $config
            ->setDelimiter(';')
            ->setToCharset('ISO-8859-1');

        $cabecalho = ['id', 'protocolo', 'empreendedor', 'cpf/cnpj empreendedor', 'empreendimento', 'cnpj empreendimento', 'municipio',
            'requerente', 'cpf requerente', 'email', 'telefone', 'supram', 'tipo', 'retifica protocolo', 'modalidade', 'classe', 'fator locacional',
            'atividade', 'status', 'processo suppri', 'data de cadastro', 'data de conclusão'];

        array_unshift($query, $cabecalho);

        $exporter = new Exporter($config);
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="Relatorio_Requerimentos_Completo.csv"');
        $exporter->export('php://output', $query);
        //$exporter->export(Yii::getAlias('@webroot/teste.csv'), $query);
        exit('Exportou! ');

        echo "<pre>";
        var_dump($query);
    }
}
