<?php

namespace app\base;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;


class MiscHelper
{
    /**
     * Se a variável não estiver vazia, retorna o campo da tabela relacionada
     * @param Model|ActiveRecord $var objeto com o relacionamento
     * @param string $field campo da tabela relacionada que deseja exibir
     * @return mixed
     */
    public static function relationalView($var, $field)
    {
        if (!is_null($var) && !empty($var)) {
            return $var->$field;
        }

        return null;
    }

    /**
     * Retorna os dados em formato compatível com dropdown
     * @param string|ActiveRecord $model Caminho completo (fully qualified name) do Model que representa os dados
     * @param string $key Campo que será usado como valor
     * @param string $value Valor que será exibido
     * @param array $where Condições para consulta
     * @param string $sortField Campo para ordenar
     * @param string $sort Tipo de ordenação
     * @return array
     */
    public static function getDropDown($model, $key = 'id', $value = 'nome', $where=null, $sortField=null, $sort=null)
    {
        $consulta = ($key !== $value) ? $model::find()->select([$key, $value]) : $model::find()->select([$key]);
        // Verifica se foi passado uma ordenação
        if (!is_null($sortField) && !is_null($sort)) {
            $consulta->orderBy([$sortField => $sort]);
        } else {
            $consulta->orderBy([$value => 'SORT_ASC']);
        }

        // Verifica se foi passado uma condição
        if (!is_null($where) && is_array($where)) {
            $consulta->where($where);
        }

        return ArrayHelper::map($consulta->asArray()->all(), $key, $value);
    }

    /**
     * Converte uma data do formato BR para o formato padrão de banco de dados
     * @param string $data data a ser convertida
     * @return string
     */
    public static function converteDataDb($data)
    {
        if (!empty($data)) {
            $dt = \DateTime::createFromFormat('d/m/Y', $data);
            return $dt->format('Y-m-d');
        }

        return null;
    }

    /**
     * Gera um protocolo único
     * @param $id
     * @param $tamanho
     * @return string
     */
    public static function geraProtocolo($id, $tamanho = 8)
    {
        $sobra = $tamanho - strlen($id);
        $rand = mt_rand(0, 999999);
        if (strlen($rand) > $sobra) {
            $rand = substr($rand, 0, $sobra);
        }
        $prot = str_pad($rand, $tamanho, $id, STR_PAD_LEFT);

        return $prot.'/'.date('Y');
    }

}