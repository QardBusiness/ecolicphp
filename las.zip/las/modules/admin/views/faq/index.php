<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\FaqSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Administração - Perguntas Frequentes';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="faq-index">

    <p>
        <?= Html::a('Cadastrar pergunta', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [

            [
                'attribute' => 'id',
                'contentOptions' => ['style' => 'width: 8%']
            ],
            'pergunta',

            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update}',
                'buttons' => [
                    'view' => function ($url, $model) {
                        return Html::a("<i class='fas fa-eye'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    },
                    'update' => function ($url, $model) {
                        return Html::a("<i class='fas fa-pencil-alt'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    },
                    'delete' => function ($url, $model) {
                        return Html::a("<i class='fas fa-trash-alt'></i>", $url, [
                            'class' => 'btn btn-danger btn-xs',
                            'data' => [
                                'confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                                'method' => 'post',
                            ],
                        ]);
                    }
                ]
            ],
        ],
    ]); ?>
</div>
