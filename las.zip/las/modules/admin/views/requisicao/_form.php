<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Requisicao */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="requisicao-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'empreendedor')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cpf_cnpj_empreendedor')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'empreendimento')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cnpj_empreendimento')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'requerente')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'cpf_requerente')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'telefone')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'modalidade')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'municipio_id')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
