<?php
ini_set('memory_limit','512M');

use app\base\MiscHelper;
use app\models\Requisicao;
use yii\helpers\Html;
use yii\grid\GridView;
use kartik\export\ExportMenu;
use yii\helpers\StringHelper;
use PhpOffice\PhpSpreadsheet\Style\Border;
use app\models\User;

/* @var $this yii\web\View */
/* @var $searchModel app\models\RequisicaoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Administração - Requisições';
$this->params['breadcrumbs'][] = $this->title;

$identity = Yii::$app->user->identity;
?>

<?php if (Yii::$app->session->hasFlash('success')) : ?>
    <div class="alert alert-success" role="alert">Requisição apagada com sucesso!</div>
<?php endif; ?>

<div class="requisicao-index">

    <div class="row container">
        <div class="pull-left">
            <?= ExportMenu::widget([
                'dataProvider' => $dataProvider,
                'filename' => 'Relatorio_Requisicoes_'.date('d-m-Y'),
                'stream' => true,
                'deleteAfterSave' => true,
                'batchSize' => 1000,
                'exportConfig' => [
                    ExportMenu::FORMAT_EXCEL => false,
                    ExportMenu::FORMAT_TEXT => false,
                    ExportMenu::FORMAT_CSV => false,
                    ExportMenu::FORMAT_HTML => false,
                    ExportMenu::FORMAT_PDF => [
                        'pdfConfig' => ['orientation' => 'L']
                    ]
                ],
                'columns' => [
                    'id',
                    'protocolo',
                    'empreendedor',
                    'cpf_cnpj_empreendedor',
                    'empreendimento',
                    'cnpj_empreendimento',
                    [
                        'attribute' => 'municipio_id',
                        'value' => 'municipio.nome'
                    ],
                    'requerente',
                    'cpf_requerente',
                    'email',
                    'telefone',
                    [
                        'attribute' => 'supram',
                        'label' => 'Supram',
                        'value' => function ($model) {
                            return $model->regional->sigla;
                        },
                    ],
                    [
                        'attribute' => 'tipo',
                        'value' => function ($model) {
                            return Requisicao::$arrayTipos[$model->tipo];
                        },
                    ],
                    [
                        'attribute' => 'retifica_protocolo',
                        'label' => 'Protocolo a retificar'
                    ],
                    [
                        'attribute' => 'modalidade',
                        'value' => function ($model) {
                            return Requisicao::$arrayModalidades[$model->modalidade];
                        },
                    ],
                    [
                        'attribute' => 'classe',
                        'value' => function($model) {
                            return !empty($model->classe) ? Requisicao::$arrayClasses[$model->classe] : null;
                        }
                    ],
                    'fator_locacional',
                    [
                        'attribute' => 'atividade_id',
                        'value' => function($model) {
                            return !empty($model->atividade_id) ? $model->atividade->codigo." ".$model->atividade->nome : null;
                        }
                    ],
                    [
                        'attribute' => 'status',
                        'value' => function($model) {return Requisicao::$arrayStatus[$model->status];}
                    ],
                    'dae',
                    [
                        'attribute' => 'processo_suppri',
                        'format' => 'boolean',
                    ],
                    [
                        'attribute' => 'data',
                        'format' => ['datetime', 'php:d/m/Y H:i'],
                    ],
                    [
                        'attribute' => 'conclusao',
                        'format' => ['datetime', 'php:d/m/Y H:i'],
                    ],
                ],
                //'fontAwesome' => true,
                'columnSelectorMenuOptions' => [
                    'style' => 'overflow-y: scroll; height:auto; max-height:500px; overflow-x:hidden; width:300px; max-width:300px'
                ],
                'dropdownOptions' => [
                    'class' => 'btn btn-default',
                    'label' => 'Exportar resultados'
                ],
                'messages' => [
                    'allowPopups' => 'Desabilite o bloqueio de popups do seu navegador para baixar corretamente.',
                    'confirmDownload' => 'Clique em OK para continuar.'
                ],
                'boxStyleOptions' => [
                    ExportMenu::FORMAT_EXCEL_X => [
                        /*'font' => [
                            'bold' => true,
                            'color' => [
                                'argb' => '000000',
                            ],
                        ],*/
                        'borders' => [
                            'outline' => [
                                'borderStyle' => Border::BORDER_NONE,
                                //'color' => ['argb' => Color::COLOR_BLACK],
                            ],
                            'inside' => [
                                'borderStyle' => Border::BORDER_NONE,
                                //'color' => ['argb' => Color::COLOR_BLACK],
                            ]
                        ],
                    ],
                ]
            ]) ?>
        </div>

        <div class="pull-right">
            <?php //echo Html::a('Gerar relatório', ['exportar-dados?'.Yii::$app->request->queryString], ['class' => 'btn btn-primary']) ?>
        </div>
    </div>



    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'pager' => [
            'firstPageLabel' => 'Início',
            'lastPageLabel'  => 'Fim'
        ],
        'columns' => [

            [
                'attribute' => 'protocolo',
                'value' => function($model) {
                    return Html::a($model->protocolo, \yii\helpers\Url::to(['requisicao/view', 'id' => $model->id]));
                },
                'format' => 'raw',
                'filter' => \yii\widgets\MaskedInput::widget([
                    'model' => $searchModel,
                    'attribute' => 'protocolo',
                    'mask' => '99999999/9999'
                ]),
                'contentOptions' => ['style' => 'width: 8%']
            ],
            'empreendimento',
            [
                'attribute' => 'cnpj_empreendimento',
                'label' => 'CPF/CNPJ empreendimento',
                'filter' => \yii\widgets\MaskedInput::widget([
                    'model' => $searchModel,
                    'attribute' => 'cnpj_empreendimento',
                    'mask' => '99.999.999/9999-99'
                ]),
                'contentOptions' => ['style' => 'width: 10%']
            ],
            [
                'attribute' => 'municipio_id',
                'label' => 'Município',
                'value' => 'municipio.nome',
                'filter' => \kartik\select2\Select2::widget([
                    'model' => $searchModel,
                    'attribute' => 'municipio_id',
                    'data' => MiscHelper::getDropDown(\app\models\Municipio::className()),
                    'options' => ['placeholder' => ''],
                    'theme' => 'bootstrap',
                    'pluginOptions' => [
                        'allowClear' => true
                    ]
                ]),
                'contentOptions' => ['style' => 'width: 15%'],
            ],
            [
                'attribute' => 'supram',
                'label' => 'Supram',
                'value' => function ($model) {
                    return $model->regional->sigla;
                },
                'filter' => MiscHelper::getDropDown(\app\models\Regional::className(), 'id', 'sigla'),
                'visible' => $identity->isAdmin || in_array($identity->perfil, [User::PERFIL_SUPPRI, User::PERFIL_LEITURA])
            ],
            [
                'attribute' => 'modalidade',
                'contentOptions' => ['style' => 'width: 20%'],
                'value' => function ($model) {
                    return StringHelper::truncateWords(Requisicao::$arrayModalidades[$model->modalidade], 2);
                },
                'filter' => Requisicao::$arrayModalidades
            ],
            [
                'attribute' => 'status',
                'value' => function ($model) {
                    return Requisicao::$arrayStatus[$model->status];
                },
                'filter' => Requisicao::$arrayStatus
            ],
            [
                'attribute' => 'processo_suppri',
                'label' => 'Suppri?',
                'format' => 'boolean',
                'filter' => [0 => 'Não', 1 => 'Sim'],
                'visible' => $identity->isAdmin || $identity->perfil === User::PERFIL_SUPPRI
            ],
            [
                'attribute' => 'tipo',
                'label' => 'Tipo',
                'format' => 'raw',
                'value' => function ($model) {
                    $tipo = Requisicao::$arrayTipos[$model->tipo];
                    return $model->tipo === 'novo' ? "<span class='label label-success' data-toggle='tooltip' title='{$tipo}'>N</span>" : "<span class='label label-warning' data-toggle='tooltip' title='{$tipo}'>R</span>";
                },
                'filter' => Requisicao::$arrayTipos
            ],
            [
                'attribute' => 'data',
                'format' => ['datetime', 'php:d/m/Y'],
                'filter' => \kartik\daterange\DateRangePicker::widget([
                    'attribute' => 'data',
                    'model' => $searchModel,
                    'convertFormat' => true,
                    'pluginOptions' => [
                        'locale' => ['format' => 'd/m/Y', 'separator' => '-'],
                        'opens' => 'left'
                    ],
                ]),
                'contentOptions' => ['style' => 'width: 8%']
            ],

            /*[
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view}',
                'buttons' => [
                    'view' => function ($url, $model) {
                        return Html::a("<i class='fas fa-eye'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    }
                ]
            ],*/
        ],
    ]); ?>
</div>
