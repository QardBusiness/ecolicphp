<?php
use app\models\Requisicao;
use yii2tech\spreadsheet\Spreadsheet;

/* @var $this yii\web\View */
/* @var $searchModel app\models\RequisicaoSearch */
/* @var $dataProvider yii\data\ArrayDataProvider */

$columns = [
    'id',
    'protocolo',
    'empreendedor',
    'cpf_cnpj_empreendedor',
    'empreendimento',
    'cnpj_empreendimento',
    [
        'attribute' => 'municipio_id',
        'label' => 'Município',
        'value' => 'municipio.nome'
    ],
    'requerente',
    'cpf_requerente',
    'email',
    'telefone',
    [
        'attribute' => 'supram',
        'label' => 'Supram',
        'value' => 'regional.sigla'
    ],
    [
        'attribute' => 'tipo',
        'value' => function ($model) {
            return !empty($model['tipo']) ? Requisicao::$arrayTipos[$model['tipo']]: null;
        },
    ],
    [
        'attribute' => 'retifica_protocolo',
        'label' => 'Protocolo a retificar'
    ],
    [
        'attribute' => 'modalidade',
        'value' => function ($model) {
            return !empty($model['modalidade']) ? Requisicao::$arrayModalidades[$model['modalidade']] : null;
        },
    ],
    [
        'attribute' => 'classe',
        'value' => function($model) {
            return !empty($model['classe']) ? Requisicao::$arrayClasses[$model['classe']] : null;
        }
    ],
    'fator_locacional',
    [
        'attribute' => 'atividade_id',
        'label' => 'Atividade',
        'value' => function($model) {
            return !empty($model['atividade_id']) ? $model['atividade']['codigo']." ".$model['atividade']['nome'] : null;
        }
    ],
    [
        'attribute' => 'status',
        'value' => function($model) {
            return !empty($model['status']) ? Requisicao::$arrayStatus[$model['status']] : null;
        }
    ],
    'dae',
    [
        'attribute' => 'processo_suppri',
        'label' => 'Processo SUPRI',
        'format' => 'boolean',
    ],
    [
        'attribute' => 'data',
        'format' => ['datetime', 'php:d/m/Y H:i'],
    ],
    [
        'attribute' => 'conclusao',
        'format' => ['datetime', 'php:d/m/Y H:i'],
    ],
];


$exporter = new Spreadsheet([
    'dataProvider' => $dataProvider,
    'columns' => $columns
]);

return $exporter->send('teste.xls');