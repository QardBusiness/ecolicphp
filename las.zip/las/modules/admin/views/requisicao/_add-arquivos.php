<?php
use kartik\form\ActiveForm;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Html;
use app\base\MiscHelper;
use app\models\TipoDocumento;

$this->title = "Adicionar arquivos";
?>

<h1>Requisição nº <?= $model->id ?></h1>

<?php $form = ActiveForm::begin(['id' => 'form-requisicao']); ?>

    <?php DynamicFormWidget::begin([
        'widgetContainer' => 'dynamicform_wrapper', // required: only alphanumeric characters plus "_" [A-Za-z0-9_]
        'widgetBody' => '.container-items', // required: css class selector
        'widgetItem' => '.item', // required: css class
        'limit' => 50, // the maximum times, an element can be cloned (default 999)
        'min' => 1, // 0 or 1 (default 1)
        'insertButton' => '.add-item', // css class
        'deleteButton' => '.remove-item', // css class
        'model' => $modelsArquivo[0],
        'formId' => 'form-requisicao',
        'formFields' => [
            'tipo_documento_id',
            'file'
        ],
    ]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-plus"></i> Adicionar documentos
            <div class="clearfix"></div>
        </div>
        <div class="panel-body"><!-- widgetContainer -->
            <table class="table table-bordered table-condensed container-items">
                <tr>
                    <th style="width: 40%">Tipo de documento</th>
                    <th>Arquivo</th>
                    <th style="width: 5%"></th>
                </tr>
                <?php foreach ($modelsArquivo as $index => $modelArquivo): ?>
                    <tr class="item">
                        <td><?= $form->field($modelArquivo, "[{$index}]tipo_documento_id")->dropDownList(MiscHelper::getDropDown(TipoDocumento::className(), 'id', 'nome', ['status' => 1]), ['prompt' => '-- SELECIONE --'])->label(false) ?></td>

                        <td>
                            <?= $form->field($modelArquivo, "[{$index}]file")->widget(\kartik\file\FileInput::className(), [
                                'language' => 'pt',
                                'pluginOptions' => [
                                    'browseLabel' => 'Selecione',
                                    'removeLabel' => 'Remover',
                                    'showPreview' => false,
                                    'showUpload' => false,
                                    'msgPlaceholder' => ''
                                ]
                            ])->label(false) ?>
                        </td>

                        <td style="padding-top: 5px">
                            <button type="button" class="pull-right remove-item btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                        </td>
                    </tr>

                <?php endforeach; ?>

            </table>
        </div>
        <div class="panel-footer">
            <button type="button" class="pull-right add-item btn btn-success btn-xs"><i class="fa fa-plus"></i> Adicionar documento</button>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php DynamicFormWidget::end(); ?>

<div class="form-group">
    <?= Html::submitButton('Enviar', ['class' => 'btn btn-success']) ?>
</div>

<?php ActiveForm::end(); ?>
<hr>
<div class="panel panel-info">
    <div class="panel-heading"><h3 class="panel-title">Documentos atuais</h3></div>
    <div class="panel-body" style="display: none"></div>
    <table class="table table table-condensed table-striped table-bordered">
        <?php foreach ($model->arquivos as $arquivo) : ?>
            <tr>
                <th><?= $arquivo->tipoDocumento->nome ?></th>
                <td><?= Html::a($arquivo->nome, "@web/{$arquivo->path}", ['target' => '_blank']) ?></td>
                <td><?= Yii::$app->formatter->asShortSize($arquivo->tamanho) ?></td>
                <td><?= $arquivo->enviado_supram ? "<span class='text-warning'>Adicionado internamente</span>" : "<span class='text-success'>Enviado pelo empreendedor</span>" ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
