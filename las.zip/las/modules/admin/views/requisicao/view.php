<?php

use app\models\Requisicao;
use app\models\User;
use yii\helpers\Html;
use kartik\detail\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Requisicao */

$this->title = "Requisição n° " . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Requisicaos', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="requisicao-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->session->hasFlash('success')) : ?>
        <div class="alert alert-success" role="alert"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>

    <div class="row container-fluid">

        <?php if (Yii::$app->user->identity->isAdmin) : ?>
            <?= Html::a('Apagar', ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger',
                'data' => [
                    'confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                    'method' => 'post',
                ],
            ]) ?>
        <?php endif; ?>

        <?php if (Yii::$app->user->identity->perfil !== User::PERFIL_LEITURA) : ?>

            <div class="btn-group">
                <button type="button" class="btn btn-default"><i class="far fa-flag"></i> Status</button>
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <?php foreach (Requisicao::$arrayStatus as $key => $status) : ?>
                        <?php if ($key !== $model->status && $key !== 'declaracao gerada') : ?>
                            <li>
                                <?= Html::a($status, ['altera-status', 'requisicao' => $model->id, 'status' => $key], [
                                    'data' => [
                                        'confirm' => 'Confirmar a alteração do status?',
                                        'method' => 'post',
                                    ],
                                ]) ?>
                            </li>
                        <?php elseif ($key === $model->status): ?>
                            <li class="disabled">
                                <?= Html::a($status.' (atual)', '#', ['disabled' => true]) ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>

            <?= Html::a('<i class="fas fa-dollar-sign"></i> Vincular DAE', ['vincular-dae', 'requisicao' => $model->id], ['class' => 'btn btn-default']) ?>

            <?php if (Yii::$app->user->identity->isAdmin || Yii::$app->user->identity->perfil === User::PERFIL_SUPPRI) : ?>
            <div class="btn-group">
                <button type="button" class="btn btn-default"><i class="fas fa-exclamation"></i> Competência da Suppri?</button>
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <?= Html::a($model->processo_suppri === 0 ? 'Sim' : 'Não', ['competencia-suppri', 'requisicao' => $model->id], [
                            'data' => [
                                'confirm' => 'Confirmar a alteração de competência?',
                                'method' => 'post',
                            ],
                        ]) ?>
                    </li>
                </ul>
            </div>
            <?php endif; ?>

            <?= Html::a('<i class="far fa-file-alt"></i> Adicionar documentos', ['add-arquivos', 'requisicao' => $model->id], ['class' => 'btn btn-default']) ?>
        <?php endif; ?>

        <span class="pull-right"><?= Html::a('<i class="fas fa-arrow-left"></i> Voltar', '#', ['class' => 'btn btn-default', 'onclick' => 'history.back()']) ?></span>
    </div>
    <br>


    <?= DetailView::widget([
        'model' => $model,
        'mode' => DetailView::MODE_VIEW,
        'condensed' => true,
        'enableEditMode' => false,
        'panel'=>[
            'heading' => 'Detalhes da requisição',
            //'headingOptions' => ['template' => '{title}'],
            'type' => 'info',
        ],
        'hideAlerts' => true,
        //'options' => ['class' => 'table table-bordered table-condensed detail-view'],
        'attributes' => [
            [
                'columns' => [
                    [
                        'attribute' => 'id',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'protocolo',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'empreendedor',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'cpf_cnpj_empreendedor',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'empreendimento',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'cnpj_empreendimento',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'requerente',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'cpf_requerente',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'email',
                        'format' => 'email',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'telefone',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'modalidade',
                        'value' => !empty($model->modalidade) ? Requisicao::$arrayModalidades[$model->modalidade] : null,
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'municipio_id',
                        'value' => $model->municipio->nome,
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'fator_locacional',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'classe',
                        'value' => !empty($model->classe) ? Requisicao::$arrayClasses[$model->classe] : null,
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'atividade_id',
                        'value' => !empty($model->atividade_id) ? $model->atividade->codigo." ".$model->atividade->nome : null,
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'dae',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'processo_suppri',
                        'format' => 'boolean',
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'status',
                        'value' => Requisicao::$arrayStatus[$model->status],
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'tipo',
                        'value' => $model->tipo === 'novo' ? Requisicao::$arrayTipos[$model->tipo] : Requisicao::$arrayTipos[$model->tipo]." ({$model->retifica_protocolo})",
                        'valueColOptions'=>['style'=>'width:30%']
                    ]
                ]
            ],
            [
                'columns' => [
                    [
                        'attribute' => 'data',
                        'format' => ['datetime', 'php:d/m/Y H:i'],
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                    [
                        'attribute' => 'conclusao',
                        'format' => ['datetime', 'php:d/m/Y H:i'],
                        'valueColOptions'=>['style'=>'width:30%']
                    ],
                ]
            ],
        ],
    ]) ?>

    <div class="panel panel-info">
        <div class="panel-heading"><h3 class="panel-title">Documentos</h3></div>
        <div class="panel-body" style="display: none"></div>
        <table class="table table table-condensed table-striped table-bordered">
            <?php foreach ($model->arquivos as $arquivo) : ?>
                <tr>
                    <th><?= $arquivo->tipoDocumento->nome ?></th>
                    <td><?= Html::a($arquivo->nome, "@web/{$arquivo->path}", ['target' => '_blank']) ?></td>
                    <td><?= Yii::$app->formatter->asShortSize($arquivo->tamanho) ?></td>
                    <td><?= $arquivo->enviado_supram ? "<span class='text-warning'>Adicionado internamente</span>" : "<span class='text-success'>Enviado pelo empreendedor</span>" ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>

</div>
<?php

$css = <<<CSS
th {
    width: 30%;
}
CSS;
$this->registerCss($css);