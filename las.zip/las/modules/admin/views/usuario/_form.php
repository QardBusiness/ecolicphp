<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="user-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'nome')->textInput(['maxlength' => true]) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'login')->textInput(['maxlength' => true]) ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'senha')->passwordInput() ?></div>
        <div class="col-md-6"><?= $form->field($model, 'senha_repeat')->passwordInput() ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'regional_id')->dropDownList(\app\base\MiscHelper::getDropDown(\app\models\Regional::className()), ['prompt' => '-- SELECIONE --']) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'perfil')->dropDownList(\app\models\User::$perfis, ['prompt' => '-- SELECIONE --']) ?></div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Salvar', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<?php
$js = <<<JS
$(function() {
   $('input[type=checkbox]').iCheck({
    checkboxClass: 'icheckbox_square-green',
    radioClass: 'iradio_square-green',
    increaseArea: '20%' // optional
  });
});
JS;
//$this->registerJs($js);