<?php

use app\models\User;
use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Administração - Usuários';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index">

    <?php if (Yii::$app->session->hasFlash('success')) : ?>
    <div class="alert alert-success" role="alert"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>

    <p>
        <?= Html::a('Cadastrar usuário', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'pager' => [
            'firstPageLabel' => 'Início',
            'lastPageLabel'  => 'Fim'
        ],
        'columns' => [

            [
                'attribute' => 'id',
                'contentOptions' => ['width' => '10%']
            ],
            'nome',
            'login',
            [
                'attribute' => 'regional_id',
                'value' => function ($model) {
                    return $model->regional->nome;
                },
                'filter' => \app\base\MiscHelper::getDropDown(\app\models\Regional::className()),
                'contentOptions' => ['width' => '20%']
            ],
            [
                'attribute' => 'perfil',
                'value' => function ($model) {
                    return User::$perfis[$model->perfil];
                },
                'filter' => User::$perfis
            ],

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{update} {delete}',
                'buttons' => [
                    'update' => function ($url, $model) {
                        return Html::a("<i class='fas fa-pencil-alt'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    },
                    'delete' => function ($url, $model) {
                        return Html::a("<i class='far fa-trash-alt'></i>", $url, [
                            'class' => 'btn btn-danger btn-xs',
                            'data' => [
                                'confirm' => 'Tem certeza que deseja remover este usuário?',
                                'method' => 'post',
                            ],
                        ]);
                    }
                ]
            ],
        ],
    ]); ?>
</div>
