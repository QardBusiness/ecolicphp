<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;


/* @var $this yii\web\View */
/* @var $model app\models\User */

$this->title = 'Alterar Senha';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="altera-senha-form">

    <?php if (Yii::$app->session->hasFlash('success')) : ?>
    <div class="alert alert-success" role="alert"><?= Yii::$app->session->getFlash('success') ?></div>
    <?php endif; ?>

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">
        <div class="col-md-6">
            <?= $form->field($model, 'senha')->passwordInput() ?>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'senha_repeat')->passwordInput() ?>
        </div>
    </div>

    <div class="form-group">
        <?= Html::submitButton('Salvar', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
