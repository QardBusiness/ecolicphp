<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\TipoDocumentoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Administração - Tipos de documentos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tipo-documento-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Cadastrar tipo de documento', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'pager' => [
            'firstPageLabel' => 'Início',
            'lastPageLabel'  => 'Fim'
        ],
        'columns' => [

            'id',
            'nome',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{update} {delete}',
                'buttons' => [
                    'update' => function ($url, $model) {
                        return Html::a("<i class='fas fa-pencil-alt'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    },
                    'delete' => function ($url, $model) {
                        return Html::a("<i class='far fa-trash-alt'></i>", $url, [
                            'class' => 'btn btn-danger btn-xs',
                            'data' => [
                                'confirm' => 'Tem certeza que desja remover este item?',
                                'method' => 'post',
                            ],
                        ]);
                    }
                ]
            ],
        ],
    ]); ?>
</div>
