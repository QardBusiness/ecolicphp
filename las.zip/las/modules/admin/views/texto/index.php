<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\TextoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Administração - Textos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="texto-index">

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            //['class' => 'yii\grid\SerialColumn'],

            'id',
            'key',
            //'conteudo:ntext',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {update}',
                'buttons' => [
                    'view' => function ($url, $model) {
                        return Html::a("<i class='fas fa-eye'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    },
                    'update' => function ($url, $model) {
                        return Html::a("<i class='fas fa-pencil-alt'></i>", $url, ['class' => 'btn btn-default btn-xs']);
                    }
                ]
            ],
        ],
    ]); ?>
</div>
