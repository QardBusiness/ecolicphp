<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use dosamigos\tinymce\TinyMce;

/* @var $this yii\web\View */
/* @var $model app\models\Texto */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="texto-form">

    <div class="alert alert-info" role="alert">
        <strong>Atenção:</strong> Não copie e cole textos preformatados do Word, pois irá gerar conflito de formatação com o padrão da página
        <br>
        Se for copiar e colar, cole o texto no bloco de notas para quebrar a formatação e só então copie e cole na página. Depois formate o texto usando o editor do próprio site.
    </div>

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'key')->textInput(['maxlength' => true, 'disabled' => $model->isNewRecord ? false : true]) ?>

    <?= $form->field($model, 'conteudo')->widget(TinyMce::className(), [
        'options' => ['rows' => 20],
        'language' => 'pt_BR',
        'clientOptions' => [
            'plugins' => [
                "advlist autolink lists link charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste"
            ],
            'toolbar' => "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
        ]
    ]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Cadastrar' : 'Salvar', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
