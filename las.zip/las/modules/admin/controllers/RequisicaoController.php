<?php

namespace app\modules\admin\controllers;

use app\base\MiscHelper;
use app\models\Arquivo;
use app\models\User;
use Goodby\CSV\Export\Standard\Exporter;
use Goodby\CSV\Export\Standard\ExporterConfig;
use Symfony\Component\Finder\Exception\AccessDeniedException;
use Yii;
use app\models\Requisicao;
use app\models\RequisicaoSearch;
use yii\db\Query;
use yii\helpers\VarDumper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\base\Model;
use yii\helpers\Inflector;
use yii2tech\spreadsheet\Spreadsheet;

/**
 * RequisicaoController implements the CRUD actions for Requisicao model.
 */
class RequisicaoController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],

            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                    'altera-status' => ['POST'],
                    'competencia-suppri' => ['POST']
                ],
            ],
        ];
    }

    /**
     * Lists all Requisicao models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new RequisicaoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Requisicao model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Deletes an existing Requisicao model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        if (!Yii::$app->user->identity->isAdmin) {
            throw new AccessDeniedException("Você não possui permissão para excluir.");
        }

        $model = $this->findModel($id);
        foreach ($model->arquivos as $arquivo) {
            $file = Yii::getAlias("@webroot/{$arquivo->path}");
            if (file_exists($file) && is_file($file)) {
                unlink($file);
            }
            $arquivo->delete();
        }
        $model->delete();
        Yii::$app->session->setFlash('success');
        return $this->redirect(['index']);
    }

    /**
     * Altera o status de uma requisição
     * @param $requisicao
     * @param $status
     */
    public function actionAlteraStatus($requisicao, $status)
    {
        if (Yii::$app->user->identity->perfil === User::PERFIL_LEITURA) {
            throw new AccessDeniedException("Você não possui permissão para executar esta ação.");
        }

        $model = Requisicao::findOne($requisicao);
        $model->aceite = 1; // Preguiça de criar um SCENARIO
        $model->status = $status;
        if (in_array($status, ['deferido', 'indeferido', 'orientado supram', 'requerimento_inepto', 'requerimento_retificado']) && empty($model->conclusao)) {
            $model->conclusao = date('Y-m-d H:i:s');
        }

        if ($model->save()) {
            Yii::$app->session->setFlash('success', 'Status alterado com sucesso!');
            $this->redirect(['view', 'id' => $requisicao]);
        }
    }

    /**
     * Vincula uma DAE a uma requisição
     * @param $requisicao
     * @return string|\yii\web\Response
     */
    public function actionVincularDae($requisicao)
    {
        if (Yii::$app->user->identity->perfil === User::PERFIL_LEITURA) {
            throw new AccessDeniedException("Você não possui permissão para executar esta ação.");
        }

        $model = Requisicao::findOne(['id' => $requisicao]);
        $model->aceite = 1;

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }
        return $this->render('_vincular_dae', [
            'model' => $model,
        ]);

    }

    public function actionCompetenciaSuppri($requisicao)
    {
        if (Yii::$app->user->identity->perfil === User::PERFIL_LEITURA) {
            throw new AccessDeniedException("Você não possui permissão para executar esta ação.");
        }

        $model = $this->findModel($requisicao);
        $model->aceite = 1;

        if ($model->processo_suppri === 1) {
            $model->processo_suppri = 0;
        } else {
            $model->processo_suppri = 1;
        }

        if ($model->save()) {
            Yii::$app->session->setFlash('success', 'Requisição atualizada com sucesso!');
            $this->redirect(['view', 'id' => $requisicao]);
        }
    }

    /**
     * Adiciona arquivos a uma requisição
     * @param $requisicao
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     * @throws \yii\db\Exception
     */
    public function actionAddArquivos($requisicao)
    {
        if (Yii::$app->user->identity->perfil === User::PERFIL_LEITURA) {
            throw new AccessDeniedException("Você não possui permissão para executar esta ação.");
        }

        $model = $this->findModel($requisicao);
        $modelsArquivo = [new Arquivo];

        if (Yii::$app->request->isPost) {
            $modelsArquivo = Model::createMultiple(Arquivo::classname());
            Model::loadMultiple($modelsArquivo, Yii::$app->request->post());

            $valid = Model::validateMultiple($modelsArquivo);
            $valid = true;


            $transaction = \Yii::$app->db->beginTransaction();

            try {

                foreach ($modelsArquivo as $i => $modelArquivo) {
                    $modelArquivo->requisicao_id = $requisicao;
                    $modelArquivo->enviado_supram = 1;
                    $modelArquivo->file = \yii\web\UploadedFile::getInstance($modelArquivo, "[{$i}]file");

                    if (isset($modelArquivo->file)) {
                        $hash = Yii::$app->security->generateRandomString(8);
                        $tipoDoc = Inflector::slug($modelArquivo->tipoDocumento->nome);
                        $nomeArquivo = "{$tipoDoc}_{$model->id}_{$hash}.{$modelArquivo->file->extension}";
                        $basepath = 'upload/'.date('mY');
                        if (!file_exists($basepath)) {
                            mkdir($basepath, 0775, true);
                        }

                        $path = $basepath.'/'.$nomeArquivo;

                        $modelArquivo->file->saveAs($path);
                        $modelArquivo->nome = $nomeArquivo;
                        $modelArquivo->path = $path;
                        $modelArquivo->tamanho = $modelArquivo->file->size;
                        $modelArquivo->extensao = $modelArquivo->file->extension;
                    }

                    if (! ($flag = $modelArquivo->save(false))) {
                        $transaction->rollBack();
                        @unlink($modelArquivo->path);
                        break;
                    }
                }

                if ($flag) {
                    $transaction->commit();
                    Yii::$app->session->setFlash('success', 'Arquivo(s) adicionado(s) com sucesso!');
                    return $this->redirect(['view', 'id' => $requisicao]);
                }
            } catch (\Exception $e) {
                $transaction->rollBack();
                Yii::error('Erro! | [requisicao/add-arquivos] | '.$e->getMessage());
                throw new ServerErrorHttpException('Houve uma falha no servidor ao processar os dados. Tente novamente mais tarde.');
            }

        }

        return $this->render('_add-arquivos', [
            'model' => $model,
            'modelsArquivo' => $modelsArquivo
        ]);
    }

    public function actionExportarDados()
    {
        ini_set('memory_limit','1024M');
        set_time_limit(240);

        $where = Yii::$app->request->queryParams['RequisicaoSearch'];
        $where['municipio.regional_id'] = $where['supram'];
        unset($where['supram'], $where['data']);
        $where = array_filter($where);

        //echo "<pre>";
        //var_dump($where); die;

        $query = (new Query())
            ->select([
                'requisicao.id',
                'requisicao.protocolo',
                'requisicao.empreendedor',
                'requisicao.cpf_cnpj_empreendedor',
                'requisicao.empreendimento',
                'requisicao.cnpj_empreendimento',
                'municipio.nome as municipio',
                'requisicao.requerente',
                'requisicao.cpf_requerente',
                'requisicao.email',
                'requisicao.telefone',
                'regional.sigla as supram',
                'requisicao.tipo',
                'requisicao.retifica_protocolo',
                'requisicao.modalidade',
                'requisicao.classe',
                'requisicao.fator_locacional',
                'atividade.nome as atividade',
                'requisicao.status',
                'requisicao.processo_suppri',
                'DATE_FORMAT(requisicao.data, "%d/%m/%Y %H:%i")',
                'DATE_FORMAT(requisicao.conclusao, "%d/%m/%Y %H:%i")'
            ])
            ->from('requisicao')
            ->leftJoin('municipio', 'requisicao.municipio_id = municipio.id')
            ->leftJoin('regional', 'municipio.regional_id = regional.id')
            ->leftJoin('atividade', 'requisicao.atividade_id = atividade.id')
            ->where($where);

        if (!empty(Yii::$app->request->queryParams['RequisicaoSearch']['data'])) {
            $data = explode('-', Yii::$app->request->queryParams['RequisicaoSearch']['data']);

            $query->andFilterWhere(['>=', 'data', MiscHelper::converteDataDb($data[0]). ' 00:00:01'])
                ->andFilterWhere(['<=', 'data', MiscHelper::converteDataDb($data[1]).' 23:59:59']);
        }

        $dados = $query->all();

        $config = new ExporterConfig();
        $config
            ->setDelimiter(';')
            ->setToCharset('ISO-8859-1');

        $cabecalho = ['id', 'protocolo', 'empreendedor', 'cpf/cnpj empreendedor', 'empreendimento', 'cnpj empreendimento', 'municipio',
            'requerente', 'cpf requerente', 'email', 'telefone', 'supram', 'tipo', 'retifica protocolo', 'modalidade', 'classe', 'fator locacional',
            'atividade', 'status', 'processo suppri', 'data de cadastro', 'data de conclusão'];

        array_unshift($dados, $cabecalho);

        $exporter = new Exporter($config);
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="Relatorio_Requerimentos_Completo_'.date('d-m-Y').'.csv"');
        $exporter->export('php://output', $dados);
        exit;
    }

    /**
     * Finds the Requisicao model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Requisicao the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Requisicao::findOne(['id' => $id])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
