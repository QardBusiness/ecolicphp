<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use app\assets\AppAsset;
use yii\helpers\StringHelper;
use yii\helpers\Url;
use kartik\dialog\Dialog;

AppAsset::register($this);
//echo Dialog::widget();

$rotas = [
    //'Apresentação' => ['url' => Url::to(['/'])],
    //'IDE' => ['url' => 'http://idesisema.meioambiente.mg.gov.br', 'options' => ['target' => '_blank']],
    'FCE Eletrônico' => ['url' => Url::to(['/site/requisicao'])],
    'Simulador' => ['url' => Url::to(['/site/simulador'])],
    'Perguntas Frequentes' => ['url' => Url::to(['/site/perguntas-respostas'])],
    //'Manuais' => ['url' => Url::to(['/site/legislacao'])],
    'Contato' => ['url' => Url::to(['/site/contato'])]
];

$usuario = !Yii::$app->user->isGuest ? StringHelper::truncateWords(Yii::$app->user->identity->nome, 1, '') : null;
$action = Yii::$app->controller->action->id;
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-115187069-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-115187069-1');
    </script>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Jonatas Ferreira Lizandro">
    <?= Html::csrfMetaTags() ?>
    <title><?= "LAS - ".Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">

    <div id="faixa-topo" class="container-fluid">
        <?php if (!Yii::$app->user->isGuest) : ?>
        <div id="menu-adm" class="container">
            <div class="pull-right">
                <ul class="list-inline">
                    <li><?= Html::a('Requisições', Url::to(['/admin/requisicao']), []) ?></li>
                    <?php if (Yii::$app->user->identity->isAdmin) : ?>
                        <li><?= Html::a('Usuários', Url::to(['/admin/usuario']), []) ?></li>
                        <li><?= Html::a('Tipos de documentos', Url::to(['/admin/tipo-documento']), []) ?></li>
                        <li><?= Html::a('Textos', Url::to(['/admin/texto']), []) ?></li>
                        <li><?= Html::a('FAQ', Url::to(['/admin/faq']), []) ?></li>
                    <?php endif; ?>
                    <li> <strong>|</strong> </li>
                    <li>
                        <div class="dropdown">
                            <a class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                                <?= $usuario ?>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
                                <li role="presentation"><?= Html::a('Alterar senha', Url::to(['/admin/usuario/alterar-senha']), ['role' => 'menuitem']) ?></li>                                </li>
                                <li role="presentation"><?= Html::a('Sair', Url::to(['/site/logout']), ['role' => 'menuitem', 'data' => ['method' => 'post']]) ?></li>
                            </ul>
                        </div>
                    </li>
                </ul>

            </div>
        </div>
        <?php endif; ?>
    </div>

    <header>
        <?php echo Html::a(Html::img('@web/img/header.png', ['class' => 'img-responsive', 'alt' => 'Logo']), Url::to(['site/index'])) ?>
    </header>

    <nav id="menu-topo" class="visible-md-block visible-lg-block">
        <ul id="navInline" class="container">
        <?php foreach ($rotas as $label => $rota) : ?>
            <li><?= Html::a($label, $rota['url'], isset($rota['options']) ? $rota['options'] : []) ?></li>
        <?php endforeach; ?>
        </ul>
    </nav>

    <nav id="menu-topo-sm" class="visible-xs-block visible-sm-block">
        <!-- Visível apenas em dispositivos menores -->
        <div class="pull-left container">
            <div class="dropdown">
                <button class="btn dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    <i class="glyphicon glyphicon-menu-hamburger"></i>
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <?php foreach ($rotas as $label => $rota) : ?>
                    <li><?= Html::a($label, $rota['url'], isset($rota['options']) ? $rota['options'] : []) ?></li>
                <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </nav>

    <br><br>
    <div id="container-titulo" class="container">
        <div id="titulo" class="visible-md-block visible-lg-block"><?= $this->title ?></div>
        <div id="titulo-sm" class="visible-xs-block visible-sm-block"><?= $this->title ?></div>
    </div>

    <div id="conteudo" class="container">
        <?= $content ?>
    </div>

    <footer class="container">
        <br>
    </footer>

    <input type="hidden" id="action" value="<?= Yii::$app->controller->id.'/'.Yii::$app->controller->action->id ?>">
    <!-- Modal -->
    <div class="modal fade" id="modalAviso" tabindex="-1" role="dialog" aria-labelledby="modalAvisoLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="modalAvisoLabel">Atenção!</h4>
                </div>
                <div class="modal-body text-justify">
                    <p>A Secretaria de Estado de Meio Ambiente e o Instituto Estadual de Florestas comunicam que a partir do dia 02.05.2018, novos processos de exploração florestal ou intervenção ambiental, vinculados ou não a processos de licenciamento ambiental, deverão ser inseridos no Sistema Nacional de Controle da Origem dos Produtos Florestais - SINAFLOR.</p>
                    <p>O SINAFLOR poderá ser acessado através do endereço eletrônico <?= Html::a('http://www.ibama.gov.br/sistemas/sinaflor', 'http://www.ibama.gov.br/sistemas/sinaflor', ['target' => '_blank']) ?></p>
                    <p>Maiores esclarecimentos poderão ser obtidos no tópico "Perguntas Frequentes” do próprio sistema ou no endereço eletrônico da Semad <?= Html::a('http://www.meioambiente.mg.gov.br', 'http://www.meioambiente.mg.gov.br', ['target' => '_blank']) ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->endBody() ?>
</body>
</html>
<?php
$js1 = <<<JS
$(function() {
    // Ativa tooltip Bootstrap
    $('[data-toggle="tooltip"]').tooltip();
    
    /*if ($('#action').val() === 'site/index') {
        $('#modalAviso').modal('show');
    }*/
});
JS;
$this->registerJs($js1);


$this->endPage()
?>


