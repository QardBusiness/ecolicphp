<?php
/* @var $this yii\web\View */
/* @var $model app\models\Texto */
$this->title = $titulo;

echo $model->conteudo;