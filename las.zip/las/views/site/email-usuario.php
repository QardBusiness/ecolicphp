<?php
use app\models\Requisicao;

/* @var $this yii\web\View */
/* @var $model app\models\Requisicao */
?>

    <?php if ($model->modalidade == 'dispensa'){
        $texto = "emitida";
    } else {
        $texto = "recebida";
        } ?>

<p>Prezado empreendedor,</p>
<p>Sua solicitação de <?= $model->modalidade == 'dispensa' ? 'declaração de dispensa' : 'licenciamento ambiental' ?> foi <?php echo $texto ?> com sucesso!<br/>O número do seu protocolo é <strong><?= $model->protocolo ?></strong></p>

<?php if ($model->modalidade == 'dispensa'){ ?>
    A sua declaração disponível na tela 10 do FCE Eletrônico só é válida acompanhada do protocolo de envio ao órgão ambiental. <br>
    <?php
} ?>


<p>Seguem os detalhes de sua solicitação:</p>

<strong>Nome do empreendedor:</strong> <?= $model->empreendedor ?><br/>
<strong>CPF/CNPJ do empreendedor:</strong> <?= $model->cpf_cnpj_empreendedor ?><br/>
<strong>Nome do empreendimento:</strong> <?= $model->empreendimento ?><br/>
<strong>CNPJ do empreendimento:</strong> <?= $model->cnpj_empreendimento ?><br/>
<strong>Nome do requerente:</strong> <?= $model->requerente ?><br/>
<strong>CPF do requerente:</strong> <?= $model->cpf_requerente ?><br/>
<strong>Telefone para contato:</strong> <?= $model->telefone ?><br/>
<strong>Modalidade:</strong> <?= Requisicao::$arrayModalidades[$model->modalidade] ?><br/>
<strong>Classe:</strong> <?= !empty($model->classe) ? Requisicao::$arrayClasses[$model->classe] : '' ?><br/>
<strong>Fator Locacional:</strong> <?= !empty($model->fator_locacional) ? $model->fator_locacional : '' ?><br/>
<strong>Atividade:</strong> <?= !empty($model->atividade_id) ? $model->atividade->codigo.' '.$model->atividade->nome : '' ?><br/>
<strong>Município do empreendimento ou atividade:</strong> <?= $model->municipio->nome ?><br/>

<br/><br/>

<p style="color: #ff0000; font-weight: bold">E-MAIL AUTOMÁTICO. FAVOR NÃO RESPONDER!</p>
