<?php

use app\base\MiscHelper;
use app\models\Requisicao;
use app\models\TipoDocumento;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\widgets\MaskedInput;
use kartik\select2\Select2;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\Url;
use kartik\dialog\Dialog;

/* @var $this yii\web\View */
/* @var $model app\models\Requisicao */
/* @var $form yii\widgets\ActiveForm */

$this->title = "FCE Eletrônico";
echo Dialog::widget();

$modalidades = Requisicao::$arrayModalidades;
unset($modalidades['dispensa']);
?>

<?php if (Yii::$app->session->hasFlash('success')) : ?>
<div class="alert alert-success" role="alert">
    Requisição enviada com sucesso!<br/>
    Protocolo: <strong><?= Yii::$app->session->getFlash('success') ?></strong>
</div>
<?php endif; ?>

<div id="versaoFCE" class="alert alert-info" role="alert">
    <strong>ATENÇÃO:</strong> Está disponível a versão 12 do FCE e do seu Manual de Preenchimento. <strong>Apenas utilize esse arquivo se for realizar uma retificação de um pedido já enviado</strong>.
</div>

<div class="requisicao-form text-justify">

    <?php $form = ActiveForm::begin(['id' => 'form-requisicao']); ?>


    <div class="well">
        <p>
            Atenção! A Secretaria de Estado de Meio Ambiente e Desenvolvimento Sustentável - Semad – passou a contar com o novo Sistema de Licenciamento Ambiental – SLA – a partir do dia 05/11/2019. Para realizar seu requerimento de licença ambiental, você deverá acessar o Portal EcoSistemas por meio do endereço:
            <a href="http://ecosistemas.meioambiente.mg.gov.br">http://ecosistemas.meioambiente.mg.gov.br</a>.
        </p>
        <p>
            Esse canal está disponível apenas para retificação de pedidos já enviados anteriormente para o órgão ambiental.
            Apenas faça o download do arquivo do Formulário de Caracterização do Empreendimento – FCE – nesse caso. Acesse o arquivo <?= Html::a('aqui', '@web/arquivos/fce-eletronico.xlsx', ['style' => 'font-weight: bold']) ?>.
        </p>
        <p>
            Atente-se para a correção e veracidade dos dados, inclusive do e-mail fornecido – o qual será utilizado como meio de comunicação oficial durante a regularização ambiental:
        </p>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'empreendedor')->textInput(['maxlength' => true]) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'cpf_cnpj_empreendedor')->widget(MaskedInput::className(), ['mask' => ['999.999.999-99', '99.999.999/9999-99']]) ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'empreendimento')->textInput(['maxlength' => true]) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'cnpj_empreendimento')->widget(MaskedInput::className(), ['mask' => ['999.999.999-99', '99.999.999/9999-99']]) ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'requerente')->textInput(['maxlength' => true]) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'cpf_requerente')->widget(MaskedInput::className(), ['mask' => ['999.999.999-99']]) ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'telefone')->widget(MaskedInput::className(), ['mask' => ['(99) 9999-9999', '(99) 99999-9999']]) ?></div>
    </div>

    <div class="row">
        <div class="col-md-6"><?= $form->field($model, 'tipo')->inline()->radioList(['retifica_fce' => 'Retificação de FCE'], ['class' => 'radio'])->label('Indique o tipo de requerimento') ?></div>
        <div class="col-md-6">
            <?= $form->field($model, 'retifica_protocolo')->widget(MaskedInput::className(), ['mask' => ['99999999/9999'], 'options' => ['disabled' => true, 'class' => 'form-control']])->label('Protocolo a ser retificado') ?>
        </div>
    </div>

    <p class="text-info"><strong>ATENÇÃO:</strong> Somente será possível retificar o FCE para requerimentos que ainda não foram analisados pelo órgão ambiental</p>
    <br>

    <div class="well">
        Insira a modalidade de licenciamento conforme FCE preenchido:
    </div>

    <?= $form->field($model, 'modalidade')->radioList($modalidades, ['class' => 'radio'])->label('Modalidade de licenciamento (conforme simulações realizadas e FCE preenchido)') ?>

    <p id="msgRasConv" class="well" style="display: none">
        <strong>ATENÇÃO: </strong> Para as modalidades de LAS RAS ou Licenciamento Convencional, a lista de documentos exibidos Tela 8 do FCE terá caráter apenas orientativo. A definitiva Orientação para Formalização de Processos de Licenciamento será encaminhada para o e-mail informado na solicitação eletrônica.
    </p>

    <p id="msgCadastro" class="well" style="display: none">
        Os formulários devem estar inteiramente preenchidos e a documentação obrigatória deve ser encaminhada corretamente. O DAE deve ser emitido com a descrição disponível na Tela 8 – Orientação para Formalização de Processos – do arquivo do FCE Eletrônico. Formulários e documentações incompletas ou contendo informações imprecisas ou incorretas não serão aceitos e ensejarão no indeferimento do requerimento.
    </p>

    <p id="msgDispensa" class="well" style="display: none">
        <strong>ATENÇÃO: </strong> Para que tenha validade, esta declaração deverá ser enviada pelo Sistema de Requerimento de Licenciamento Ambiental e o número de protocolo deverá ser guardado.
    </p>

    <div class="row" id="classe_teste">
        <div class="col-md-6"><?= $form->field($model, 'classe')->dropDownList(Requisicao::$arrayClasses, ['prompt' => '-- SELECIONE --']) ?></div>
        <div class="col-md-6"><?= $form->field($model, 'fator_locacional')->dropDownList([0, 1, 2], ['prompt' => '-- SELECIONE --']) ?></div>
    </div>

    <?= $form->field($model, 'atividade_id')->widget(Select2::className(), [
        'data' => MiscHelper::getDropDown(\app\models\Atividade::className()),
        'options' => ['placeholder' => '-- SELECIONE --'],
        'theme' => 'bootstrap',
        'pluginOptions' => [
            'allowClear' => true
        ]
    ])
    ?>

    <?= $form->field($model, 'municipio_id')->widget(Select2::className(), [
        'data' => MiscHelper::getDropDown(\app\models\Municipio::className()),
        'options' => ['placeholder' => '-- SELECIONE --'],
        'theme' => 'bootstrap',
        'pluginOptions' => [
            'allowClear' => true
        ]
    ])
    ?>

    <?php DynamicFormWidget::begin([
        'widgetContainer' => 'dynamicform_wrapper', // required: only alphanumeric characters plus "_" [A-Za-z0-9_]
        'widgetBody' => '.container-items', // required: css class selector
        'widgetItem' => '.item', // required: css class
        'limit' => 50, // the maximum times, an element can be cloned (default 999)
        'min' => 1, // 0 or 1 (default 1)
        'insertButton' => '.add-item', // css class
        'deleteButton' => '.remove-item', // css class
        'model' => $modelsArquivo[0],
        'formId' => 'form-requisicao',
        'formFields' => [
            'tipo_documento_id',
            'file'
        ],
    ]); ?>


    <div class="panel panel-default">
        <div class="panel-heading">
            <i class="far fa-file-alt"></i> Documentos
            <div class="clearfix"></div>
        </div>
        <div class="panel-body"><!-- widgetContainer -->
            <table class="table table-bordered table-condensed container-items">
                <tr>
                    <th style="width: 40%">Tipo de documento</th>
                    <th>Arquivo</th>
                    <th style="width: 5%"></th>
                </tr>
                <?php foreach ($modelsArquivo as $index => $modelArquivo): ?>
                    <tr class="item">
                        <td><?= $form->field($modelArquivo, "[{$index}]tipo_documento_id")->dropDownList(MiscHelper::getDropDown(TipoDocumento::className(), 'id', 'nome', ['status' => 1]), ['prompt' => '-- SELECIONE --'])->label(false) ?></td>

                        <td>
                            <?= $form->field($modelArquivo, "[{$index}]file")->widget(\kartik\file\FileInput::className(), [
                                'language' => 'pt',
                                'pluginOptions' => [
                                    'browseLabel' => 'Selecione',
                                    'removeLabel' => 'Remover',
                                    'showPreview' => false,
                                    'showUpload' => false,
                                    'msgPlaceholder' => ''
                                ]
                            ])->label(false) ?>
                        </td>

                        <td style="padding-top: 5px">
                            <button type="button" class="pull-right remove-item btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                        </td>
                    </tr>

                <?php endforeach; ?>

            </table>
        </div>
        <div class="panel-footer">
            <button type="button" class="pull-right add-item btn btn-success btn-xs"><i class="fa fa-plus"></i> Adicionar documento</button>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php DynamicFormWidget::end(); ?>


    <div class="well">
        <p>Declaro, sob as penas da lei, que todas as informações prestadas estão corretas e atualizadas, bem como que o e-mail fornecido poderá ser utilizado como meio de comunicação oficial no procedimento de regularização ambiental do meu empreendimento</p>
        <p>Declaro que o requerimento trata de retificação de FCE solicitada pelo órgão ambiental e estou ciente que para novo pedido devo acessar o Portal EcoSistemas</p>
    </div>

    <?= $form->field($model, 'aceite')->checkbox() ?>

    <div class="form-group">
        <?= Html::submitButton('Enviar', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<?php
$js = <<<JS
$(function() {
    
   // krajeeDialog.alert($('#versaoFCE').html());
    
   // Aplica o iCheck nos Radio Inputs
   $('input[type=radio]').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
        //increaseArea: '20%' // optional
   });
   
   // Acessa os parâmetros do Dynamicforms
   var varDF = $('.dynamicform_wrapper').attr('data-dynamicform');
   var dfParams = window[varDF];

   // Aplica as regras de acordo com a modalidade selecionada   
   $('input[name="Requisicao[modalidade]"]').on('ifChecked', function() {
       
       var valor = $(this).val();
       var btnAdd = $('.add-item');
       
       // Remove todos os campos dinamicos extras
       $('.remove-item').trigger('click');
       
       if (valor === 'ras' || valor === 'convencional') {
           $('#msgRasConv').show();
           $('#msgCadastro').hide();
           $('#msgDispensa').hide();
           $('#requisicao-fator_locacional option[value="2"]').prop('disabled', false).text('2');
           dfParams.min = 2;
           dfParams.limit = 3;
           
           $("#requisicao-classe").prop( "disabled", false ).val('');
           $("#requisicao-fator_locacional").prop( "disabled", false).val('');
           $("#requisicao-atividade_id").prop( "disabled", false).val("").trigger('change');
           
           btnAdd.prop('disabled', false);
           
           $('#arquivo-0-tipo_documento_id').val(4).attr({readonly: true, 'aria-disabled': true});
           $('#arquivo-0-tipo_documento_id').parent().parent().parent().find('button.remove-item').prop('disabled', true);
           btnAdd.trigger('click');
           
           $('#arquivo-1-tipo_documento_id').val(37).attr({readonly: true, 'aria-disabled': true});
           $('#arquivo-1-tipo_documento_id').parent().parent().parent().find('button.remove-item').prop('disabled', true);
           btnAdd.trigger('click');
           
           $('#arquivo-2-tipo_documento_id').val(40).attr({readonly: true, 'aria-disabled': true});
           
       } else if (valor === 'dispensa') {
           $('#msgRasConv').hide();
           $('#msgCadastro').hide();
           $('#msgDispensa').show();
           $('#requisicao-fator_locacional option[value="2"]').prop('disabled', false).text('2');
           dfParams.min = 1;
           dfParams.limit = 1;
           
           $("#requisicao-classe").prop( "disabled", true ).val('');
           $("#requisicao-fator_locacional").prop( "disabled", true ).val('');
           $("#requisicao-atividade_id").prop( "disabled", true ).val("").trigger('change');
           
           // Certifica de que apenas o FCE será exigido
           $('.remove-item').prop('disabled', false).trigger('click');
           
           $('#arquivo-0-tipo_documento_id').val(37).attr({readonly: true, 'aria-disabled': true}); // Define o valor como FCE e bloqueia o campo
           $('.add-item, .remove-item').prop('disabled', true);
           
       } else { // LAS CADASTRO
           $('#msgRasConv').hide();
           $('#msgDispensa').hide();
           $('#msgCadastro').show();
           $('#requisicao-fator_locacional option[value="2"]').prop('disabled', true).append(' - Desabilitado para LAS Cadastro');
           dfParams.min = 1;
           dfParams.limit = 50;
           
           $('.add-item, .remove-item').prop('disabled', false);
           
           $("#requisicao-classe").prop( "disabled", false ).val('');
           $("#requisicao-fator_locacional").prop( "disabled", false ).val('');
           $("#requisicao-atividade_id").prop( "disabled", false ).val("").trigger('change');
           
           $('select[id*="tipo_documento_id"]').val('').attr({readonly: false, 'aria-disabled': false});
           
           krajeeDialog.alert('Comunicamos que a partir do dia 01/10/2018 os requerimentos de LAS CADASTRO somente serão aceitos com a documentação completa. A inobservância desta exigência poderá implicar em indeferimento da solicitação da referida licença.');
       }
   });
   
   $('input[name="Requisicao[tipo]"]').on('ifChecked', function() {
       var valor = $(this).val();
       
       if (valor === 'retifica_fce') {
           $('#requisicao-retifica_protocolo').prop('disabled', false);
       } else {
           $('#requisicao-retifica_protocolo').prop('disabled', true).val('');
       }
       
   });
   
   $(".dynamicform_wrapper").on("afterInsert", function(e, item) {
       var modalidade = $('input[name="Requisicao[modalidade]"]:checked').val();
       
       // Garante que o terceiro documento que é opcional, seja o documento correto
       if (modalidade === 'ras' || modalidade === 'convencional') {
           $('#arquivo-2-tipo_documento_id').val(40).attr({readonly: true, 'aria-disabled': true});
       }
       
   });
});
JS;
$this->registerJs($js);

$css = <<<CSS
select[readonly] {
  background: #eee; /* Simular campo inativo */
  pointer-events: none;
  touch-action: none;
}
CSS;
$this->registerCss($css);