<?php
/* @var $this yii\web\View */

$this->title = "Contato";
?>

<div id="contato" style="text-align: justify">
    <table id="tblContato" class="table table-responsive table-bordered table-condensed">
        <tr>
            <th>Ano de lavratura</th>
            <th>Autuante</th>
            <th>Responsável pelo processamento</th>
            <th colspan="2">Telefone para contato</th>
        </tr>
        <tr>
            <td rowspan="3">Até 2011</td>
            <td rowspan="3">PMMG ou Técnicos vinculados ao IEF, FEAM ou IGAM</td>
            <td>Núcleo de Autos de Infração - IEF</td>
            <td colspan="2">(31) 3915-1425</td>
        </tr>
        <tr>
            <td>Núcleo de Autos de Infração - FEAM</td>
            <td colspan="2">(31) 3915-1421</td>
        </tr>
        <tr>
            <td>Núcleo de Autos de Infração - IGAM</td>
            <td colspan="2">(31) 3915-1281</td>
        </tr>
        <tr>
            <td>2011 a 2015</td>
            <td>PMMG</td>
            <td rowspan="3">Diretoria de Autos de Infração - DAINF</td>
            <td colspan="2" rowspan="3">(31) 3915-1280</td>
        </tr>
        <tr>
            <td>2011 a 2014</td>
            <td>Extintos núcleos de fiscalização - Sufis</td>
        </tr>
        <tr>
            <td>A partir de 2016</td>
            <td>Diretorias de fiscalização - SUFIS e Operações Especiais</td>
        </tr>
        <tr>
            <td rowspan="2">2015 e 2016</td>
            <td rowspan="2">Extintos núcleos de fiscalização - SUFIS</td>
            <td rowspan="9">Núcleo de Autos de Infração - NAI Supram</td>
            <td>Alto São Francisco</td>
            <td>(37) 3229-2877</td>
        </tr>
        <tr>
            <td>Central-Metropolitana</td>
            <td>(31) 3228-7798</td>
        </tr>
        <tr>
            <td rowspan="2">A partir de 2016</td>
            <td rowspan="2">PMMG</td>
            <td>Jequitinhonha</td>
            <td>(38) 3532-6665</td>
        </tr>
        <tr>
            <td>Leste Mineiro</td>
            <td>(33) 3202-7470</td>
        </tr>
        <tr>
            <td rowspan="2">A partir de 2016</td>
            <td rowspan="2">Diretorias Regionais de Fiscalização</td>
            <td>Noroeste de Minas</td>
            <td>(38) 3677-9861</td>
        </tr>
        <tr>
            <td>Norte de Minas</td>
            <td>(38) 3212-3267</td>
        </tr>
        <tr>
            <td rowspan="3">Sempre</td>
            <td rowspan="3">Técnicos vinculados à regularização da Supram</td>
            <td>Sul de Minas</td>
            <td>(35) 3229-1993</td>
        </tr>
        <tr>
            <td>Triângulo Mineiro e Alto Paranaíba</td>
            <td>(34) 3088-6417</td>
        </tr>
        <tr>
            <td>Zona da Mata</td>
            <td>(32) 3539-2706</td>
        </tr>
    </table>
</div>
<?php
$css = <<<CSS
#tblContato {
    text-align: center;
}

#tblContato th {
    text-align: center;
    background-color: #f5f5f5;
}

#tblContato td {
    vertical-align: middle;
}
CSS;
$this->registerCss($css);
