<?php
/* @var $this yii\web\View */

$this->title = "FCE Eletrônico";
?>

<div style="text-align: center">
    <?= \yii\helpers\Html::img('@web/img/ok.png') ?><br>
    <h4>Dados enviados com sucesso!</h4>
    <p>Protocolo: <?= $protocolo ?></p>
</div>
