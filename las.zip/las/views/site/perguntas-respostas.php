<?php
$this->title = "Perguntas Frequentes";

/* @var $this yii\web\View */
/* @var $models app\models\Faq */
?>

<div id="preguntas-respostas" style="text-align: justify">

    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

        <?php foreach ($models as $i => $model) : ?>
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="p<?= $i ?>">
                <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?= $i ?>" aria-expanded="true" aria-controls="collapse<?= $i ?>">
                        <?= $model->pergunta ?>
                    </a>
                </h4>
            </div>
            <div id="collapse<?= $i ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="p<?= $i ?>">
                <div class="panel-body">
                    <?= $model->resposta ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>