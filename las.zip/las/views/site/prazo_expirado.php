<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\MaskedInput;
use kartik\select2\Select2;
use wbraganca\dynamicform\DynamicFormWidget;
use yii2mod\alert\Alert;

/* @var $this yii\web\View */
/* @var $model app\models\Dados */
/* @var $form ActiveForm */

$dropdownMunicipios = \yii\helpers\ArrayHelper::map(\app\models\Municipio::find()->all(), 'id', 'nome');

$this->title = "Faça sua adesão";
?>

<div class="jumbotron">
    <p>O prazo para adesão ao programa expirou!</p>
</div>



