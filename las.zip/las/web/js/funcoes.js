// Torna o campo "Especificar Agente Autuante" obrigatório
function verificaAgenteOutros(id) {
    var index = id.split('_outros');
    return $("#"+index[0]).val() == 'Outros';
}

function verificaTipoDoc(attr) {
    var index = attr.input.split('-');
    return $('#arquivo-'+index[1]+'-tipo_documento_id').val();
}