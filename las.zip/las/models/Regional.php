<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "regional".
 *
 * @property integer $id
 * @property string $nome
 * @property string $sigla
 *
 * @property Municipio[] $municipios
 * @property Usuario[] $usuarios
 */
class Regional extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'regional';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nome', 'sigla'], 'required'],
            [['nome'], 'string', 'max' => 255],
            [['sigla'], 'string', 'max' => 45],
            [['sigla'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nome' => 'Nome',
            'sigla' => 'Sigla',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMunicipios()
    {
        return $this->hasMany(Municipio::className(), ['regional_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsuarios()
    {
        return $this->hasMany(Usuario::className(), ['regional_id' => 'id']);
    }
}
