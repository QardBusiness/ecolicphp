<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "municipio".
 *
 * @property integer $id
 * @property string $nome
 * @property integer $regional_id
 *
 * @property Regional $regional
 * @property Requisicao[] $requisicaos
 */
class Municipio extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'municipio';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nome', 'regional_id'], 'required'],
            [['regional_id'], 'integer'],
            [['nome'], 'string', 'max' => 255],
            [['regional_id'], 'exist', 'skipOnError' => true, 'targetClass' => Regional::className(), 'targetAttribute' => ['regional_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nome' => 'Nome',
            'regional_id' => 'Regional ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRegional()
    {
        return $this->hasOne(Regional::className(), ['id' => 'regional_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequisicaos()
    {
        return $this->hasMany(Requisicao::className(), ['municipio_id' => 'id']);
    }
}
