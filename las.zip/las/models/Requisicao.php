<?php

namespace app\models;

use app\base\MiscHelper;
use yii\web\JsExpression;
use Yii;

/**
 * This is the model class for table "requisicao".
 *
 * @property integer $id
 * @property string $empreendedor
 * @property string $cpf_cnpj_empreendedor
 * @property string $empreendimento
 * @property string $cnpj_empreendimento
 * @property string $requerente
 * @property string $cpf_requerente
 * @property string $email
 * @property string $telefone
 * @property string $tipo
 * @property string $retifica_protocolo
 * @property string $modalidade
 * @property integer $municipio_id
 * @property string $classe
 * @property integer $atividade_id
 * @property integer $fator_locacional
 * @property integer $status
 * @property string $data
 * @property string $conclusao
 * @property string $protocolo
 * @property string $dae
 * @property integer $processo_suppri
 *
 * @property Municipio $municipio
 * @property Atividade $atividade
 * @property Regional $regional
 * @property Arquivo[] $arquivos
 */
class Requisicao extends \yii\db\ActiveRecord
{

    public $aceite;
    public $fce;
    public $supram;

    public static $arrayModalidades = [
        'cadastro' => 'LAS Cadastro',
        'ras' => 'LAS RAS',
        'convencional' => 'Licenciamento Convencional (LP, LI e LO concedidas em fase sucessivas ou concomitantes)',
        'dispensa' => 'Declaração de Dispensa',
        'e-05-07-0' => 'Atividade E-05-07-0 (LAS/RAS)'
    ];

    public static $arrayTipos = [
        'novo' => 'Novo requerimento',
        'retifica_fce' => 'Retificação de FCE'
    ];

    public static $arrayClasses = [
        'classe 1' => 'Classe 1',
        'classe 2' => 'Classe 2',
        'classe 3' => 'Classe 3',
        'classe 4' => 'Classe 4',
        'classe 5' => 'Classe 5',
        'classe 6' => 'Classe 6',
    ];

    public static $arrayStatus = [
        'em aberto' => 'Requerimento em aberto',
        'em analise' => 'Requerimento em análise',
        'deferido' => 'Requerimento deferido',
        'indeferido' => 'Requerimento indeferido',
        'orientado supram' => 'Requerimento orientado para a Supram',
        'declaracao gerada' => 'Declaração gerada',
        'requerimento_inepto' => 'Requerimento inepto',
        'requerimento sobrestado' => 'Requerimento sobrestado',
        'requerimento_retificado' => 'Requerimento retificado',
        'cancelado' => 'Requerimento Cancelado'
    ];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'requisicao';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['empreendedor', 'cpf_cnpj_empreendedor', 'empreendimento', 'cnpj_empreendimento', 'requerente', 'cpf_requerente', 'email', 'telefone', 'modalidade', 'municipio_id', 'tipo'], 'required'],
            [['classe', 'fator_locacional', 'atividade_id'], 'required',
                'when' => function($model) { return $model->modalidade != 'dispensa'; },
                'whenClient' => new JsExpression("function(attribute, value) {return $('input[name=\"Requisicao[modalidade]\"]:checked').val() != 'dispensa';}")
            ],
            [['retifica_protocolo'], 'required',
                'when' => function($model) { return $model->tipo == 'retifica_fce'; },
                'whenClient' => new JsExpression("function(attribute, value) {return $('input[name=\"Requisicao[tipo]\"]:checked').val() == 'retifica_fce';}")
            ],
            [['municipio_id', 'supram', 'atividade_id', 'fator_locacional'], 'integer'],
            [['empreendedor', 'empreendimento', 'requerente', 'email'], 'string', 'max' => 255],
            [['cpf_cnpj_empreendedor', 'cnpj_empreendimento'], 'string', 'max' => 18],
            [['cpf_requerente', 'protocolo', 'retifica_protocolo'], 'string', 'max' => 14],
            [['dae'], 'string', 'min' => 13, 'max' => 13],
            [['dae'], 'unique', 'message' => 'DAE já vinculado a outro requerimento'],
            [['telefone'], 'string', 'max' => 15],
            [['tipo'], 'string', 'max' => 45],
            [['email'], 'email'],
            [['processo_suppri'], 'boolean'],
            [['data', 'conclusao'], 'safe'],
            [['aceite'], 'required', 'requiredValue' => 1, 'message' => 'Você deve aceitar os termos'],
            [['status'], 'default', 'value' => function($model, $attr) { return $model->modalidade == 'dispensa' ? 'declaracao gerada' : 'em aberto';}],
            //[['retifica_protocolo'], 'exist', 'targetAttribute' => 'protocolo', 'message' => 'O protocolo informado não existe'],
            [['municipio_id'], 'exist', 'skipOnError' => true, 'targetClass' => Municipio::className(), 'targetAttribute' => ['municipio_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'empreendedor' => 'Nome do empreendedor',
            'cpf_cnpj_empreendedor' => 'CPF/CNPJ do empreendedor',
            'empreendimento' => 'Nome do empreendimento',
            'cnpj_empreendimento' => 'CPF/CNPJ do empreendimento',
            'requerente' => 'Nome do requerente',
            'cpf_requerente' => 'CPF do requerente',
            'email' => 'Email para contato eletrônico',
            'telefone' => 'Telefone para contato',
            'tipo' => 'Tipo de requerimento',
            'retifica_protocolo' => 'Protocolo retificado',
            'modalidade' => 'Modalidade',
            'municipio_id' => 'Município do empreendimento ou atividade',
            'aceite' => 'Declaro que estou ciente',
            'supram' => 'Supram',
            'classe' => 'Classe',
            'atividade_id' => 'Atividade',
            'status' => 'Status',
            'data' => 'Data de cadastro',
            'conclusao' => 'Data de conclusão',
            'dae' => 'DAE',
            'processo_suppri' => 'Processo de competência da Suppri'
        ];
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'sammaye\audittrail\LoggableBehavior'
        ];
    }

    /**
     * Envia um e-mail para o usuário com o protocolo e os dados preenchidos
     */
    public function enviaEmail()
    {
        $mail = Yii::$app->mailer->compose('@app/views/site/email-usuario', ['model' => $this])
            ->setFrom(['noreply@meioambiente.mg.gov.br' => 'SISEMA-MG'])
            ->setTo($this->email)
            ->setSubject('Solicitação de licenciamento recebida');

        $mail->send();
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getMunicipio()
    {
        return $this->hasOne(Municipio::className(), ['id' => 'municipio_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getArquivos()
    {
        return $this->hasMany(Arquivo::className(), ['requisicao_id' => 'id']);
    }

    public function getRegional()
    {
        return $this->hasOne(Regional::className(), ['id' => 'regional_id'])->via('municipio');
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getAtividade()
    {
        return $this->hasOne(Atividade::className(), ['id' => 'atividade_id']);
    }
}
