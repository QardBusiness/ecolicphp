<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "texto".
 *
 * @property integer $id
 * @property string $key
 * @property string $conteudo
 */
class Texto extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'texto';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['key', 'conteudo'], 'required'],
            [['conteudo'], 'string'],
            [['key'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'key' => 'Key',
            'conteudo' => 'Conteudo',
        ];
    }
}
