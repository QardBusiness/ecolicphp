<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "atividade".
 *
 * @property integer $id
 * @property string $codigo
 * @property string $nome
 *
 * @property Requisicao[] $requisicaos
 */
class Atividade extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'atividade';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['codigo', 'nome'], 'required'],
            [['nome'], 'string'],
            [['codigo'], 'string', 'max' => 45],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'codigo' => 'Codigo',
            'nome' => 'Nome',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequisicaos()
    {
        return $this->hasMany(Requisicao::className(), ['atividade_id' => 'id']);
    }
}
