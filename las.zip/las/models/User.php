<?php

namespace app\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "usuario".
 *
 * @property int $id
 * @property string $nome
 * @property string $login
 * @property string $senha
 * @property int $regional_id
 * @property string $senha_repeat
 * @property int $perfil
 *
 * @property Regional $regional
 */
class User extends ActiveRecord implements \yii\web\IdentityInterface
{
    const SCENARIO_UPDATE = 'update';
    const SCENARIO_ALTERA_SENHA = 'altera-senha';
    const PERFIL_TEC = 0;
    const PERFIL_ADMIN = 1;
    const PERFIL_SUPPRI = 2;
    const PERFIL_LEITURA = 3;

    public $senha_repeat;

    public static $perfis = [
        self::PERFIL_TEC => 'Técnico',
        self::PERFIL_SUPPRI => 'Suppri',
        self::PERFIL_ADMIN => 'Administrador',
        self::PERFIL_LEITURA => 'Somente Leitura'
    ];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuario';
    }

    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios[self::SCENARIO_UPDATE] = ['nome', 'login', 'senha', 'senha_repeat', 'regional_id', 'perfil'];
        $scenarios[self::SCENARIO_ALTERA_SENHA] = ['senha', 'senha_repeat'];
        return $scenarios;
    }


    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nome', 'login', 'regional_id', 'perfil'], 'required'],
            [['regional_id', 'perfil'], 'integer'],
            [['nome', 'login', 'senha'], 'string', 'max' => 255],
            [['login'], 'unique'],
            [['senha_repeat'], 'compare', 'compareAttribute' => 'senha', 'message' => 'As senhas não conferem'],

            [['senha', 'senha_repeat'], 'required', 'on' => ['default', self::SCENARIO_ALTERA_SENHA]],

            [['regional_id'], 'exist', 'skipOnError' => true, 'targetClass' => Regional::className(), 'targetAttribute' => ['regional_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nome' => 'Nome',
            'login' => 'Login',
            'senha' => 'Senha',
            'senha_repeat' => 'Repita a Senha',
            'regional_id' => 'Regional',
            'perfil' => 'Perfil de acesso'
        ];
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id)
    {
        $usuario = self::findOne(['id' => $id]);
        if ($usuario) {
            return new static($usuario);
        }

        return null;
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return null;
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        $usuario = self::findOne(['login' => $username]);
        if ($usuario) {
            return new static($usuario);
        }

        return null;
    }

    /**
     * @inheritdoc
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey)
    {
        return null;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password)
    {
        return password_verify($password, $this->senha);
    }

    /**
     * Verifica se um usuário é ADMIN
     * @return bool
     */
    public function getIsAdmin()
    {
        return $this->perfil === self::PERFIL_ADMIN;
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRegional()
    {
        return $this->hasOne(Regional::className(), ['id' => 'regional_id']);
    }
}
