<?php

namespace app\models;

use app\base\MiscHelper;
use kartik\daterange\DateRangeBehavior;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Requisicao;
use yii\data\ArrayDataProvider;

/**
 * RequisicaoSearch represents the model behind the search form about `app\models\Requisicao`.
 */
class RequisicaoSearch extends Requisicao
{

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'municipio_id', 'supram', 'processo_suppri'], 'integer'],
            [['empreendedor', 'cpf_cnpj_empreendedor', 'empreendimento', 'cnpj_empreendimento', 'requerente', 'cpf_requerente', 'email', 'telefone', 'tipo', 'modalidade', 'data', 'protocolo', 'status', 'retifica_protocolo'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider|ArrayDataProvider
     */
    public function search($params, $array = false)
    {
        $query = Requisicao::find();

        $query->joinWith(['regional', 'atividade']);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'municipio_id' => $this->municipio_id,
            'protocolo' => $this->protocolo,
            'status' => $this->status,
            'tipo' => $this->tipo
        ]);

        $query->andFilterWhere(['like', 'empreendedor', $this->empreendedor])
            ->andFilterWhere(['like', 'cpf_cnpj_empreendedor', $this->cpf_cnpj_empreendedor])
            ->andFilterWhere(['like', 'empreendimento', $this->empreendimento])
            ->andFilterWhere(['like', 'cnpj_empreendimento', $this->cnpj_empreendimento])
            ->andFilterWhere(['like', 'requerente', $this->requerente])
            ->andFilterWhere(['like', 'cpf_requerente', $this->cpf_requerente])
            ->andFilterWhere(['like', 'email', $this->email])
            ->andFilterWhere(['like', 'telefone', $this->telefone])
            ->andFilterWhere(['like', 'modalidade', $this->modalidade]);

        if (!empty($this->data)) {
            $data = explode('-', $this->data);
            $query->andFilterWhere(['>=', 'data', MiscHelper::converteDataDb($data[0]). ' 00:00:01'])
                ->andFilterWhere(['<=', 'data', MiscHelper::converteDataDb($data[1]).' 23:59:59']);
        }

        if (!Yii::$app->user->identity->isAdmin && Yii::$app->user->identity->perfil !== User::PERFIL_LEITURA) {
            if (Yii::$app->user->identity->perfil === User::PERFIL_SUPPRI) {
                $query->andFilterWhere(['regional.id' => $this->supram]);
                $query->andFilterWhere(['processo_suppri' => $this->processo_suppri]);
            } else {
                $query->andFilterWhere(['regional.id' => Yii::$app->user->identity->regional_id]);
                $query->andFilterWhere(['processo_suppri' => 0]);
            }
        } else {
            $query->andFilterWhere(['regional.id' => $this->supram]);
            $query->andFilterWhere(['processo_suppri' => $this->processo_suppri]);
        }

        if ($array) {
            $all = [];
            foreach ($query->asArray()->each(1000) as $each) {
                $all[] = $each;
            }

            $arrayDataProvider = new ArrayDataProvider([
                'allModels' => $all,
                'pagination' => [
                    'pageSize' => 20
                ]
            ]);
        }

        return !$array ? $dataProvider : $arrayDataProvider;
    }
}
