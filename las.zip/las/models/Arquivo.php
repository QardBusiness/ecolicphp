<?php

namespace app\models;

use Yii;
use yii\web\JsExpression;
use yii\web\UploadedFile;


/**
 * This is the model class for table "arquivo".
 *
 * @property int $id
 * @property string $nome
 * @property string $path
 * @property string $tamanho
 * @property string $extensao
 * @property int $tipo_documento_id
 * @property int $requisicao_id
 * @property boolean $enviado_supram
 *
 * @property Requisicao $requisicao
 * @property TipoDocumento $tipoDocumento
 */
class Arquivo extends \yii\db\ActiveRecord
{

    /**
     * @var UploadedFile
     */
    public $file;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'arquivo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            //[['nome', 'path', 'tamanho', 'extensao', 'tipo_documento_id', 'requisicao_id'], 'required'],
            [['tipo_documento_id'], 'required'],
            [['tipo_documento_id', 'requisicao_id'], 'integer'],
            [['nome', 'path'], 'string', 'max' => 255],
            [['tamanho', 'extensao'], 'string', 'max' => 45],
            [['enviado_supram'], 'boolean'],
            [['file'], 'file', 'skipOnEmpty' => false, 'maxSize' => '20982000'],
            [['file'], 'file', 'skipOnEmpty' => false, 'maxSize' => '20982000', 'extensions' => ['kml', 'zip'],
                'when' => function ($model) { return $model->tipo_documento_id == 8; },
                'whenClient' => new JsExpression("function (attribute, value) { return verificaTipoDoc(attribute) == 8; }")
            ],
            [['requisicao_id'], 'exist', 'skipOnError' => true, 'targetClass' => Requisicao::className(), 'targetAttribute' => ['requisicao_id' => 'id']],
            [['tipo_documento_id'], 'exist', 'skipOnError' => true, 'targetClass' => TipoDocumento::className(), 'targetAttribute' => ['tipo_documento_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nome' => 'Nome',
            'path' => 'Path',
            'tamanho' => 'Tamanho',
            'extensao' => 'Extensão',
            'tipo_documento_id' => 'Tipo de documento',
            'requisicao_id' => 'Requisicao ID',
            'file' => 'Arquivo'
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRequisicao()
    {
        return $this->hasOne(Requisicao::className(), ['id' => 'requisicao_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTipoDocumento()
    {
        return $this->hasOne(TipoDocumento::className(), ['id' => 'tipo_documento_id']);
    }
}
