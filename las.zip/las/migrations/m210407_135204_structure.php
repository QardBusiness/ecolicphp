<?php

use yii\db\Migration;

/**
 * Class m210407_135204_structure
 */
class m210407_135204_structure extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        Yii::$app->db->createCommand(
            "
            CREATE SCHEMA IF NOT EXISTS `las` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
USE `las` ;

-- -----------------------------------------------------
-- Table `las`.`atividade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`atividade` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `codigo` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `nome` TEXT CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 239
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`regional`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`regional` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `sigla` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `sigla_UNIQUE` (`sigla` ASC) )
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`municipio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`municipio` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `regional_id` INT(11) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_municipio_regional_idx` (`regional_id` ASC) ,
  CONSTRAINT `fk_municipio_regional`
    FOREIGN KEY (`regional_id`)
    REFERENCES `las`.`regional` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 854
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`requisicao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`requisicao` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `empreendedor` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `cpf_cnpj_empreendedor` VARCHAR(18) CHARACTER SET 'utf8' NOT NULL,
  `empreendimento` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `cnpj_empreendimento` VARCHAR(18) CHARACTER SET 'utf8' NOT NULL,
  `municipio_id` INT(11) NOT NULL,
  `requerente` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `cpf_requerente` VARCHAR(14) CHARACTER SET 'utf8' NOT NULL,
  `email` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `telefone` VARCHAR(15) CHARACTER SET 'utf8' NOT NULL,
  `tipo` VARCHAR(45) NOT NULL DEFAULT 'novo',
  `retifica_protocolo` VARCHAR(13) NULL DEFAULT NULL,
  `modalidade` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `status` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `classe` VARCHAR(8) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `atividade_id` INT(11) NULL DEFAULT NULL,
  `fator_locacional` INT(1) NULL DEFAULT NULL,
  `data` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `conclusao` DATETIME NULL DEFAULT NULL,
  `protocolo` VARCHAR(13) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `dae` VARCHAR(13) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `processo_suppri` TINYINT(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  INDEX `fk_requisicao_municipio1_idx` (`municipio_id` ASC) ,
  INDEX `fk_requisicao_atividade1_idx` (`atividade_id` ASC) ,
  CONSTRAINT `fk_requisicao_atividade1`
    FOREIGN KEY (`atividade_id`)
    REFERENCES `las`.`atividade` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_requisicao_municipio1`
    FOREIGN KEY (`municipio_id`)
    REFERENCES `las`.`municipio` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 11867
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`tipo_documento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`tipo_documento` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `status` TINYINT(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 45
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`arquivo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`arquivo` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `path` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `tamanho` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `extensao` VARCHAR(45) CHARACTER SET 'utf8' NOT NULL,
  `tipo_documento_id` INT(11) NOT NULL,
  `requisicao_id` INT(11) NOT NULL,
  `enviado_supram` TINYINT(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  INDEX `fk_arquivo_tipo_arquivo1_idx` (`tipo_documento_id` ASC) ,
  INDEX `fk_arquivo_requisicao1_idx` (`requisicao_id` ASC) ,
  CONSTRAINT `fk_arquivo_requisicao1`
    FOREIGN KEY (`requisicao_id`)
    REFERENCES `las`.`requisicao` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_arquivo_tipo_arquivo1`
    FOREIGN KEY (`tipo_documento_id`)
    REFERENCES `las`.`tipo_documento` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 37082
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`audit_trail`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`audit_trail` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `old_value` TEXT CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `new_value` TEXT CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `action` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `model` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `field` VARCHAR(255) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `stamp` DATETIME NOT NULL,
  `user_id` VARCHAR(255) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `model_id` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_audit_trail_user_id` (`user_id` ASC) ,
  INDEX `idx_audit_trail_model_id` (`model_id` ASC) ,
  INDEX `idx_audit_trail_model` (`model` ASC) ,
  INDEX `idx_audit_trail_field` (`field` ASC) ,
  INDEX `idx_audit_trail_action` (`action` ASC) )
ENGINE = InnoDB
AUTO_INCREMENT = 190974
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`faq`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`faq` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `pergunta` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `resposta` TEXT CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`migration`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`migration` (
  `version` VARCHAR(180) CHARACTER SET 'utf8' NOT NULL,
  `apply_time` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`version`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`texto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`texto` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `key` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `conteudo` LONGTEXT CHARACTER SET 'utf8' NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;


-- -----------------------------------------------------
-- Table `las`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `las`.`usuario` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `login` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `senha` VARCHAR(255) CHARACTER SET 'utf8' NOT NULL,
  `regional_id` INT(11) NOT NULL,
  `perfil` TINYINT(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `login_UNIQUE` (`login` ASC) ,
  INDEX `fk_usuario_regional1_idx` (`regional_id` ASC) ,
  CONSTRAINT `fk_usuario_regional1`
    FOREIGN KEY (`regional_id`)
    REFERENCES `las`.`regional` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 99
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;
            "
        )->execute();
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m210407_135204_structure cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210407_135204_structure cannot be reverted.\n";

        return false;
    }
    */
}
